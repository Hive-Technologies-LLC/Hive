# HiveOS Core

Deterministic battery data normalization engine for messy CSV and JSON battery datasets.

HiveOS Core transforms inconsistent vendor battery files into a clean, standardized, auditable structure that is immediately ready for analysis, storage, visualization, or downstream machine learning pipelines.

---

# Project Purpose

Battery datasets are often inconsistent between vendors, labs, and testing environments.

Examples:
- `Voltage (V)`
- `pack_voltage`
- `cell_voltage`
- `V_cell`

may all represent the same concept.

HiveOS Core exists to:
- normalize inconsistent battery datasets
- preserve auditability
- standardize structures
- reduce manual preprocessing work
- create a reliable ingestion layer before analytics

---

# Current Features

## File Upload
Supports:
- CSV
- JSON

---

## Validation
Frontend + backend validation:
- unsupported file detection
- empty file detection
- invalid JSON detection
- invalid CSV detection
- upload error handling

---

## Data Processing
HiveOS Core currently:
- detects file structure
- extracts rows and columns
- validates tabular format
- normalizes fields
- preserves unknown columns
- generates processing summaries

---

## Results Dashboard
The frontend dashboard currently includes:

### Overview
- mapping coverage
- mapped/unmapped columns
- conversions
- warnings
- processing summary

### Mapping Details
- source column mapping
- confidence tracking
- schema matching

### Audit Trail
- conversion history
- standardizations
- validation actions
- transformation traceability

### Data Preview
- normalized output preview
- datatype visibility
- export preview tools

### Warnings
- unmapped fields
- range issues
- quality recommendations

---

# Tech Stack

## Frontend
- HTML
- CSS
- JavaScript (Vanilla)

## Backend
- FastAPI

## Core Engine
- Python

---

# Project Structure

```text
HiveOS Core/
│
├── index.html
├── results.html
├── README.md
│
├── assets/
│   └── logo/
│
├── css/
│   ├── upload/
│   │   ├── tokens.css
│   │   └── app.css
│   │
│   └── results/
│       ├── tokens.css
│       └── index.css
│
├── js/
│   ├── dom.js
│   ├── main.js
│   ├── messages.js
│   ├── validators.js
│   └── utils.js
│
├── backend/
│   ├── api.py
│   └── src/
│       └── core.py
│
└── mock/
    └── sample_datasets/

FRONTEND FLOW

index.html
(upload page)
        ↓
main.js
(validates file)
        ↓
POST /api/load-file
(FastAPI backend)
        ↓
Core pipeline processes file
        ↓
summary returned
        ↓
sessionStorage saves result
        ↓
redirect → results.html
        ↓
dashboard renders results