"""
Project: HiveOS Core
File: converters.py
Purpose: Convert known normalized fields into HiveOS Core standard value formats.
Key Constraints:
- Do not rename columns
- Do not guess unknown fields
- Do not drop data
- Do not modify the original DataFrame
- Record meaningful conversions for audit
"""

import re

import pandas as pd

from src.conversion_registry import CONVERSION_REGISTRY


def parse_number(value) -> float | None:
    """
    Extract a numeric value from common battery data strings.
    """
    if value is None:
        return None

    if isinstance(value, (int, float)):
        return float(value)

    text = str(value).strip()

    if not text:
        return None

    match = re.search(r"-?(?:\d+(?:\.\d+)?|\.\d+)", text)

    if not match:
        return None

    return float(match.group())


def convert_temperature_to_celsius(value):
    """
    Convert temperature values into Celsius when possible.
    """
    number = parse_number(value)

    if number is None:
        return value, None

    text = str(value).lower()

    if "f" in text and "c" not in text:
        converted = (number - 32) * 5 / 9
        return round(converted, 2), "fahrenheit_to_celsius"

    return number, None


def convert_voltage_to_volts(value):
    """
    Convert voltage values into volts when possible.
    """
    number = parse_number(value)

    if number is None:
        return value, None

    text = str(value).lower()

    if "mv" in text:
        return round(number / 1000, 6), "millivolts_to_volts"

    return number, None


def convert_current_to_amps(value):
    """
    Convert current values into amps when possible.
    """
    number = parse_number(value)

    if number is None:
        return value, None

    text = str(value).lower()

    if "ma" in text:
        return round(number / 1000, 6), "milliamps_to_amps"

    return number, None


CONVERTER_FUNCTIONS = {
    "convert_temperature_to_celsius": convert_temperature_to_celsius,
    "convert_voltage_to_volts": convert_voltage_to_volts,
    "convert_current_to_amps": convert_current_to_amps,
}


def apply_conversions(df: pd.DataFrame) -> tuple[pd.DataFrame, list[dict]]:
    """
    Apply value conversions to active known normalized fields.

    Returns:
    - converted DataFrame
    - conversion audit records
    """
    converted_df = df.copy()
    conversion_audit = []

    for column, config in CONVERSION_REGISTRY.items():
        if not config.get("active", False):
            continue

        if column not in converted_df.columns:
            continue

        converter_name = config.get("converter")
        converter = CONVERTER_FUNCTIONS.get(converter_name)

        if converter is None:
            continue

        for row_index, original_value in converted_df[column].items():
            converted_value, conversion_name = converter(original_value)

            converted_df.at[row_index, column] = converted_value

            if conversion_name:
                conversion_audit.append({
                    "field": column,
                    "row": int(row_index),
                    "conversion": conversion_name,
                    "original_value": original_value,
                    "converted_value": converted_value,
                })

    return converted_df, conversion_audit