"""
Project: HiveOS Core
File: conversion_registry.py
Purpose: Central registry for active and future value conversions.
"""

CONVERSION_REGISTRY = {
    # -------------------------------------------------
    # Active MVP fields
    # -------------------------------------------------

    "temp_c": {
        "active": True,
        "converter": "convert_temperature_to_celsius",
        "standard_unit": "celsius",
        "supported_conversions": [
            "fahrenheit_to_celsius",
            "celsius_string_to_number",
        ],
    },

    "voltage_v": {
        "active": True,
        "converter": "convert_voltage_to_volts",
        "standard_unit": "volts",
        "supported_conversions": [
            "millivolts_to_volts",
            "volts_string_to_number",
        ],
    },

    "current_a": {
        "active": True,
        "converter": "convert_current_to_amps",
        "standard_unit": "amps",
        "supported_conversions": [
            "milliamps_to_amps",
            "amps_string_to_number",
        ],
    },

    # -------------------------------------------------
    # Future percent / ratio fields
    # -------------------------------------------------

    "soc_percent": {
        "active": False,
        "converter": "convert_percent_field",
        "standard_unit": "percent",
        "supported_conversions": [
            "decimal_to_percent",
            "percent_string_to_number",
        ],
    },

    "soh_percent": {
        "active": False,
        "converter": "convert_percent_field",
        "standard_unit": "percent",
        "supported_conversions": [
            "decimal_to_percent",
            "percent_string_to_number",
        ],
    },

    "dod_percent": {
        "active": False,
        "converter": "convert_percent_field",
        "standard_unit": "percent",
        "supported_conversions": [
            "decimal_to_percent",
            "percent_string_to_number",
        ],
    },

    # -------------------------------------------------
    # Future capacity / energy fields
    # -------------------------------------------------

    "capacity_ah": {
        "active": False,
        "converter": "convert_capacity_to_ah",
        "standard_unit": "amp_hours",
        "supported_conversions": [
            "mah_to_ah",
            "ah_string_to_number",
        ],
    },

    "energy_wh": {
        "active": False,
        "converter": "convert_energy_to_wh",
        "standard_unit": "watt_hours",
        "supported_conversions": [
            "kwh_to_wh",
            "mwh_to_wh",
            "wh_string_to_number",
        ],
    },

    "power_w": {
        "active": False,
        "converter": "convert_power_to_watts",
        "standard_unit": "watts",
        "supported_conversions": [
            "mw_to_w",
            "kw_to_w",
            "w_string_to_number",
        ],
    },

    # -------------------------------------------------
    # Future resistance / impedance fields
    # -------------------------------------------------

    "resistance_ohm": {
        "active": False,
        "converter": "convert_resistance_to_ohm",
        "standard_unit": "ohms",
        "supported_conversions": [
            "milliohm_to_ohm",
            "kohm_to_ohm",
            "ohm_string_to_number",
        ],
    },

    "impedance_ohm": {
        "active": False,
        "converter": "convert_resistance_to_ohm",
        "standard_unit": "ohms",
        "supported_conversions": [
            "milliohm_to_ohm",
            "kohm_to_ohm",
            "ohm_string_to_number",
        ],
    },

    # -------------------------------------------------
    # Future timestamp / duration fields
    # -------------------------------------------------

    "timestamp": {
        "active": False,
        "converter": "convert_timestamp",
        "standard_unit": "iso_8601",
        "supported_conversions": [
            "unix_seconds_to_iso",
            "unix_milliseconds_to_iso",
            "datetime_string_to_iso",
        ],
    },

    "duration_s": {
        "active": False,
        "converter": "convert_duration_to_seconds",
        "standard_unit": "seconds",
        "supported_conversions": [
            "milliseconds_to_seconds",
            "minutes_to_seconds",
            "hours_to_seconds",
        ],
    },

    # -------------------------------------------------
    # Future count / status fields
    # -------------------------------------------------

    "cycle_count": {
        "active": False,
        "converter": "convert_cycle_count",
        "standard_unit": "count",
        "supported_conversions": [
            "cycle_string_to_integer",
            "comma_number_to_integer",
        ],
    },

    "fault_active": {
        "active": False,
        "converter": "convert_boolean_status",
        "standard_unit": "boolean",
        "supported_conversions": [
            "yes_no_to_boolean",
            "true_false_to_boolean",
            "one_zero_to_boolean",
            "on_off_to_boolean",
        ],
    },

    "charging_active": {
        "active": False,
        "converter": "convert_boolean_status",
        "standard_unit": "boolean",
        "supported_conversions": [
            "yes_no_to_boolean",
            "true_false_to_boolean",
            "one_zero_to_boolean",
            "on_off_to_boolean",
        ],
    },
}