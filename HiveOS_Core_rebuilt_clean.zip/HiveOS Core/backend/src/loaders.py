"""
Project: HiveOS Core
File: loaders.py
Purpose: Load supported input files into a pandas DataFrame for downstream processing.
Key Constraints:
- Support .csv and .json only
- Do not perform normalization or mapping
- Fail clearly on invalid input
"""

from pathlib import Path

import pandas as pd


SUPPORTED_SUFFIXES = {".csv", ".json"}

def load_dataframe(file_path: str | Path) -> pd.DataFrame:
    """
    Load a supported file into a pandas DataFrame.

    Why this exists:
    - Defines the trusted input boundary for HiveOS Core
    - Keeps file ingestion separate from normalization logic

    Parameters:
    - file_path: Path to a .csv or .json file

    Returns:
    - pandas.DataFrame

    Raises:
    - FileNotFoundError: File does not exist
    - ValueError: Unsupported file type, malformed content, empty dataset,
      duplicate columns, or unusable JSON structure
    - OSError: File cannot be opened due to OS-level issues
    """
    path = Path(file_path)

    if not path.exists():
        raise FileNotFoundError(f"Input file does not exist: {path}")

    if not path.is_file():
        raise ValueError(f"Input path is not a file: {path}")

    suffix = path.suffix.lower()
    if suffix not in SUPPORTED_SUFFIXES:
        allowed = ", ".join(sorted(SUPPORTED_SUFFIXES))
        raise ValueError(f"Unsupported file type: {suffix or '<none>'}. Allowed types: {allowed}")

    if suffix == ".csv":
        df = _load_csv(path)
    else:
        df = _load_json(path)

    _validate_loaded_dataframe(df, path)
    return df


def _load_csv(path: Path) -> pd.DataFrame:
    """
    Load CSV content into a DataFrame.

    Why this exists:
    - Keeps per-format logic isolated and easy to test
    """
    try:
        return pd.read_csv(path)
    except pd.errors.EmptyDataError as exc:
        raise ValueError("Input file is empty.") from exc
    except pd.errors.ParserError as exc:
        raise ValueError("Invalid CSV format.") from exc
    except UnicodeDecodeError as exc:
        raise ValueError("CSV file could not be decoded as text.") from exc
    except OSError:
        raise
    except Exception as exc:
        raise ValueError("Failed to load CSV file.") from exc


def _load_json(path: Path) -> pd.DataFrame:
    """
    Load JSON content into a DataFrame.

    Why this exists:
    - Accepts only tabular JSON that pandas can safely convert
    """
    try:
        raw = pd.read_json(path)
    except ValueError as exc:
        raise ValueError("Invalid JSON format.") from exc
    except OSError:
        raise
    except Exception as exc:
        raise ValueError("Failed to load JSON file.") from exc

    if not isinstance(raw, pd.DataFrame):
        raise ValueError("JSON structure is not tabular.")

    return raw


def _validate_loaded_dataframe(df: pd.DataFrame, path: Path) -> None:
    """
    Validate the loaded DataFrame at the system boundary.

    Why this exists:
    - Prevents bad input from reaching downstream logic
    - Keeps Task 1 behavior predictable and explicit
    """
    if df.empty:
        raise ValueError("Input file is empty.")

    if df.columns.empty:
        raise ValueError("Input file has no usable columns.")

    if df.columns.duplicated().any():
        raise ValueError(f"Input file contains duplicate column names: {path.name}")
