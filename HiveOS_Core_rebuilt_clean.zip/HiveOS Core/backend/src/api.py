"""
Project: HiveOS Core
File: api.py
Purpose: Minimal FastAPI boundary for HiveOS Core file ingestion.

Key Constraints:
- Support CSV and JSON upload only
- Keep API thin
- Delegate Core processing to src/core.py
"""

from pathlib import Path
from tempfile import NamedTemporaryFile

from fastapi import FastAPI, File, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware

from src.core import process_file


app = FastAPI(title="HiveOS Core API")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Tighten later for production.
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


def format_file_size(size_bytes: int) -> str:
    """
    Convert raw byte size into a frontend-friendly display string.
    """
    if size_bytes < 1024:
        return f"{size_bytes} B"

    if size_bytes < 1024 * 1024:
        return f"{size_bytes / 1024:.1f} KB"

    return f"{size_bytes / (1024 * 1024):.1f} MB"


@app.get("/health")
def health_check() -> dict:
    """
    Simple health check for frontend connection testing.
    """
    return {"status": "ok"}


@app.post("/api/load-file")
async def load_file(file: UploadFile = File(...)) -> dict:
    """
    Receive an uploaded CSV or JSON file, pass it into the HiveOS Core
    pipeline, and return the processing result.
    """
    if not file.filename:
        raise HTTPException(status_code=400, detail="Missing file name.")

    suffix = Path(file.filename).suffix.lower()

    if suffix not in {".csv", ".json"}:
        raise HTTPException(
            status_code=400,
            detail="Unsupported file type. Only .csv and .json are allowed.",
        )

    try:
        content = await file.read()
        file_size = len(content)

        if file_size == 0:
            raise HTTPException(status_code=400, detail="Selected file is empty.")

        with NamedTemporaryFile(delete=False, suffix=suffix) as temp_file:
            temp_file.write(content)
            temp_path = Path(temp_file.name)

        result = process_file(temp_path)

        result.setdefault("file", {})
        result["file"].update(
            {
                "name": file.filename,
                "type": suffix.lstrip(".").upper(),
                "size_bytes": file_size,
                "size_display": format_file_size(file_size),
            }
        )

        return result

    except HTTPException:
        raise
    except FileNotFoundError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except ValueError as exc:
        raise HTTPException(status_code=400, detail=str(exc)) from exc
    except OSError as exc:
        raise HTTPException(status_code=500, detail=f"File read error: {exc}") from exc
    except Exception as exc:
        raise HTTPException(status_code=500, detail="Unexpected server error.") from exc
    finally:
        if "temp_path" in locals() and temp_path.exists():
            temp_path.unlink()