"""
Project: HiveOS Core
File: normalizers.py
Purpose: Apply matched canonical field names to a DataFrame.
Key Constraints:
- Do not clean column names
- Do not perform alias matching
- Do not modify values
- Do not mutate the original DataFrame
"""

import pandas as pd


def normalize_dataframe(
    df: pd.DataFrame,
    cleaned_columns: list[str],
    mapped_fields: dict[str, str],
) -> pd.DataFrame:
    """
    Normalize DataFrame column names using matcher output.

    Parameters:
    - df: Original loaded DataFrame
    - cleaned_columns: Cleaned column names from Cleaner
    - mapped_fields: Matcher output mapping cleaned names to canonical names

    Returns:
    - New DataFrame with normalized column names

    Raises:
    - ValueError: cleaned_columns length does not match DataFrame column count
    """
    if len(cleaned_columns) != len(df.columns):
        raise ValueError("Cleaned column count must match DataFrame column count.")

    normalized_df = df.copy()
    normalized_columns = []

    for original_col, cleaned_col in zip(df.columns, cleaned_columns):
        if cleaned_col in mapped_fields:
            normalized_columns.append(mapped_fields[cleaned_col])
        else:
            normalized_columns.append(cleaned_col)

    normalized_df.columns = normalized_columns

    return normalized_df