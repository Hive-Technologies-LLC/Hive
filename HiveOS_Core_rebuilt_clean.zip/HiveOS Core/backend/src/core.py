"""
Project: HiveOS Core
File: core.py
Purpose: Orchestrate HiveOS Core processing pipeline.
"""

from pathlib import Path

from src.audit import build_audit_payload
from src.cleaners import clean_colname
from src.converters import apply_conversions
from src.loaders import load_dataframe
from src.matchers import MAPPING_VERSION, SCHEMA_VERSION, match_columns
from src.normalizers import normalize_dataframe


def process_file(file_path: str | Path) -> dict:
    """
    Run the current HiveOS Core MVP pipeline.

    Current pipeline:
    - load file into DataFrame
    - clean column names
    - match columns to canonical schema
    - normalize DataFrame column names
    - convert known values into standard formats
    - generate audit payload

    Returns:
    - structured summary data for API response
    """
    path = Path(file_path)

    # 1. Load file
    df = load_dataframe(path)

    # 2. Extract and clean column names
    original_columns = list(map(str, df.columns))
    cleaned_columns = [clean_colname(col) for col in original_columns]

    # 3. Match columns to canonical schema
    match_result = match_columns(cleaned_columns)
    mapped_fields = match_result["mapped_fields"]
    unmapped_fields = match_result["unmapped_fields"]

    # 4. Normalize DataFrame column names
    normalized_df = normalize_dataframe(
        df=df,
        cleaned_columns=cleaned_columns,
        mapped_fields=mapped_fields,
    )

    normalized_columns = list(map(str, normalized_df.columns))

    # 5. Convert known values into standard formats
    converted_df, conversion_audit = apply_conversions(normalized_df)

    # 6. Build warnings
    warnings = []
    if unmapped_fields:
        warnings.append("Some fields could not be mapped.")

    # 7. Build audit payload
    audit = build_audit_payload(
        original_columns=original_columns,
        cleaned_columns=cleaned_columns,
        normalized_columns=normalized_columns,
        mapped_fields=mapped_fields,
        unmapped_fields=unmapped_fields,
        conversion_audit=conversion_audit,
    )

    return {
        "status": "success",
        "schema_version": SCHEMA_VERSION,
        "mapping_version": MAPPING_VERSION,
        "file": {
            "name": path.name,
            "row_count": int(df.shape[0]),
            "column_count": int(df.shape[1]),
        },
        "columns": {
            "original": original_columns,
            "cleaned": cleaned_columns,
            "normalized": normalized_columns,
        },
        "mapping": {
            "mapped_fields": mapped_fields,
            "unmapped_fields": unmapped_fields,
        },
        "audit": audit,
        "warnings": warnings,
        "data_preview": converted_df.head(5).to_dict(orient="records"),
        "validation": "File processed, normalized, converted, and audited successfully.",
    }