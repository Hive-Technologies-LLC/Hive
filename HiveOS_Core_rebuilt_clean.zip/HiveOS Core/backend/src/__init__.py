"""
Project: HiveOS Core
File: __init__.py
Purpose: Minimal package marker for Task 1 source files.
"""
