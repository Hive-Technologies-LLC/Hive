"""
Project: HiveOS Core
File: cleaners.py
Purpose: Clean raw column names into a consistent internal format.
Key Constraints:
- Do not perform schema matching
- Do not modify DataFrames here
- Keep behavior deterministic
"""

import re


def clean_colname(name: str) -> str:
    """
    Standardize a raw column name for later pipeline stages.

    Why this exists:
    - Makes raw names predictable before alias matching
    - Reduces formatting noise without guessing meaning

    Parameters:
    - name: Raw column name or other value

    Returns:
    - Cleaned column name as a string
    """
    if not isinstance(name, str):
        name = str(name)

    cleaned = name.strip().lower()

    # Replace any non-alphanumeric characters with underscore
    cleaned = re.sub(r"[^a-z0-9]+", "_", cleaned)

    # Collapse multiple underscores into one
    cleaned = re.sub(r"_+", "_", cleaned)

    return cleaned.strip("_")