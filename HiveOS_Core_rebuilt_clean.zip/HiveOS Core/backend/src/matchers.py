"""
Project: HiveOS Core
File: matchers.py
Purpose: Map cleaned column names to canonical schema fields.
Key Constraints:
- Do not clean column names (handled by Cleaner)
- Do not modify DataFrame (handled by Normalizer)
- Do not guess ambiguous fields
- Keep behavior deterministic
"""

# -------------------------------
# Version Metadata
# -------------------------------

SCHEMA_VERSION = "core-schema-v0.1"
MAPPING_VERSION = "core-mapping-v0.1"


# -------------------------------
# Canonical Schema (MVP)
# -------------------------------

CANONICAL_FIELDS = {
    "voltage_v",
    "current_a",
    "temp_c",
}


# -------------------------------
# MVP Alias Map
# -------------------------------

MVP_ALIASES = {
    # Voltage
    "voltage": "voltage_v",
    "pack_voltage": "voltage_v",
    "battery_voltage": "voltage_v",

    # Current
    "current": "current_a",
    "amps": "current_a",
    "amps_now": "current_a",

    # Temperature
    "temp": "temp_c",
    "temperature": "temp_c",
    "temperature_c": "temp_c",
}


# -------------------------------
# Core Matching Function
# -------------------------------

def match_columns(columns: list[str]) -> dict:
    """
    Match cleaned column names to canonical schema fields.

    Parameters:
    - columns: list of cleaned column names

    Returns:
    - dict with:
        mapped_fields: {cleaned_column: canonical_field}
        unmapped_fields: [columns not matched]
    """
    mapped_fields = {}
    unmapped_fields = []
    used_targets = set()

    for col in columns:
        # 1. Exact canonical match
        if col in CANONICAL_FIELDS:
            if col not in used_targets:
                mapped_fields[col] = col
                used_targets.add(col)
            else:
                unmapped_fields.append(col)
            continue

        # 2. Alias match
        if col in MVP_ALIASES:
            target = MVP_ALIASES[col]

            if target not in used_targets:
                mapped_fields[col] = target
                used_targets.add(target)
            else:
                unmapped_fields.append(col)
            continue

        # 3. Unknown field
        unmapped_fields.append(col)

    return {
        "mapped_fields": mapped_fields,
        "unmapped_fields": unmapped_fields,
    }